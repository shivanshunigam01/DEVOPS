## Ansible - My First Playbook

1. Write a playbook that will:
  a. Install the package zlib
  b. Create the file `/tmp/some_file`
2. Run the playbook on a remote host
