## AWS EC2 - Placement Groups          

### Objectives                      

A. Create a placement group. It should be one with a low latency network. Make sure to launch an instance as part of this placement group.
B. Create another placement group. This time high availability is a priority
