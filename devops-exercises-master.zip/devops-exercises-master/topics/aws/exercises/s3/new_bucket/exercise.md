# Create buckets

## Objectives

1. Create the following buckets:
   1. Private bucket
      1. eu-west-2 region
      2. Upload a single file to the bucket. Any file.
   2. Public bucket
      1. eu-west-1 region
      2. Versioning should be enabled

## Solution

Click [here](solution.md) to view the solution