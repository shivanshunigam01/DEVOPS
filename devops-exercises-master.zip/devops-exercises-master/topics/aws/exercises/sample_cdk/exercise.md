### Set up a CDK Project

Initialize a CDK project and set up files required to build a CDK project.

## Solution

Click [here](solution.md) to view the solution.