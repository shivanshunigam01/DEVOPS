## URL Function

Create a basic AWS Lambda function that will be triggered when you enter a URL in the browser

## Solution

Click [here to view to solution](solution.md)