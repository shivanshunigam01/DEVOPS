# Navigation

## Requirements

1. Linux :)

## Objectives

1. Change directory to `/tmp`
2. Move to parent directory
3. Change directory to home directory
4. Move to parent directory
5. Move again to parent directory
   1. Where are you at? Verify with a command
6. Change to last visited directory

## Solution

```
cd /tmp
cd ..
cd ~
cd ..
cd ..
# root (/)
pwd
cd -
```