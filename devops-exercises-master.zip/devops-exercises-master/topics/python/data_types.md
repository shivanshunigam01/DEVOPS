## Data Types

For each of the following, identify what is the data type of the result variable

1. a = [1, 2, 3, 4, 5]
2. b = "Hello, is it me you looking for?"
3. e = 100
4. f = '100'
5. i = 0.100
6. i = True

Bonus question: how to find out in Python what is the data type of certain variable?
