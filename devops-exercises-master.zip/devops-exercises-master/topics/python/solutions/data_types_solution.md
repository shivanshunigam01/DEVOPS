## Data Types - Solution

1. a = [1, 2, 3, 4, 5] -> list
2. b = "Hello, is it me you looking for?" -> string
3. e = 100 -> int
4. f = '100' -> string
5. i = 0.100 -> float
6. i = True -> bool

### Bonus question - Answer

`type(...)`
