## Directories Comparison

### Objectives

1. You are given two directories as arguments and the output should be any difference between the two directories
