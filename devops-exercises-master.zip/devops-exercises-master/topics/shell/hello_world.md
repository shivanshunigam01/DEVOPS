## Shell Scripting - Hello World

### Objectives

1. Define a variable with the string 'Hello World'
2. Print the value of the variable you've defined and redirect the output to the file "amazing_output.txt"
