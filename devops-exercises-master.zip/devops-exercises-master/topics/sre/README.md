# Site Reliability Engineering

## SRE Questions

<details>
<summary>What is SLO (service-level objective)?</summary><br><b>
</b></details>

<details>
<summary>What is SLA (service-level agreement)?</summary><br><b>
</b></details>
